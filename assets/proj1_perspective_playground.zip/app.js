const colors = ['#8d81f3', 'red', 'blue', 'yellow', 'orange', 'violet', 'darkred'];
const vm = Vue.createApp({
  data() {
    return {
      perspective: 100,
      rotateX: 0,
      rotateY: 0,
      rotateZ: 0,
      myColor: '#8d81f3',
      diy: 'diy0'
    }
  },
  computed: {
    h2Clr() { return {color: this.myColor} },
    btnClr() { return { backgroundColor: this.myColor } },
    bdrClr() { return { borderColor: this.myColor } },
    bkgClr() { return { background: this.myColor } },
    box() {
      return {
        transform: `
          perspective(${this.perspective}px)
          rotateX(${this.rotateX}deg)
          rotateY(${this.rotateY}deg)
          rotateZ(${this.rotateZ}deg)`
      }
    }
  },
  methods: {
    toggleClr() {
      const index = Math.floor(Math.random() * colors.length);
      this.myColor = colors[index];
      this.diy = `diy${index}`;
    },
    reset() {
      this.perspective = 100;
      this.rotateX = 0;
      this.rotateY = 0;
      this.rotateZ = 0;
      this.toggleClr();
    },
    async copy() {
      const transform = this.box.transform.split(/\s+/).join(' ');
      const text = `transform:${transform}`;
      await navigator.clipboard.writeText(text);
      console.warn('CSS copied to the Clipboard!');
      this.toggleClr();
    }
  }
}).mount('#app');